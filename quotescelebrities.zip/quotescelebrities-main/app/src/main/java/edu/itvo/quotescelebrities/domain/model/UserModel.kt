package edu.itvo.quotescelebrities.domain.model

data class UserModel(
    val id: Int,
    val account:String,
    val password: String,
)
