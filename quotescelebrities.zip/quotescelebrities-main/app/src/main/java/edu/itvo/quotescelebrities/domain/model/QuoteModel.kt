package edu.itvo.quotescelebrities.domain.model

data class QuoteModel(val id: Int,
                      val quote:String,
                      val author: String)
